#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  2 23:32:15 2019

@author: ichinichi
"""
#config file containing credentials for RDS MySQL instance
db_host = 'slack-rds-instance.cxuizi9o1yo0.us-west-2.rds.amazonaws.com'
db_username = 'slacko'
db_password = 'slackowacko'
db_name = 'slack_rds_database' 